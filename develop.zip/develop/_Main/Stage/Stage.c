#include "../Core.h"
#include "Stage.h"
#include "../Player_Enemy/Player_Enemy.h"
#include "../Display.h"
#include "../Sprites.h"
#include "../Item/Item.h"

//0329 �ڳ���
/* --- Stage ---*/

STAGE stage_info[3] = {
	// �� ����, {���� ����ġ METEOR, FAST, SHOOTER, BOSS}, ��������, �������, ü�¹��
	{
		.max_enemies = 20,
		.spawn_weight = {80, 20, 0 ,0},
		.target_time = 3600,
		.spawn_interval = 3.0f, 
		.score_multiplier = 1.0f, 
		.life_multiplier = 1.0f
	},
		{
		.max_enemies = 30,
		.spawn_weight = {20, 40, 40 ,0},
		.spawn_interval = 2.0f,
		.target_time = 7200,
		.score_multiplier = 1.5f,
		.life_multiplier = 2.0f
	},
		{
		.max_enemies = 40,
		.spawn_weight = {20, 40, 40 ,0},
		.target_time = 9600,
		.spawn_interval = 1.0f,
		.score_multiplier = 2.0f,
		.life_multiplier = 4.0f
	}
};

void stage_init()
{
	stage_num = 0;
	boss_spawned = false;
}

void stage_update()
{
	if (!boss_spawned && frames >= (CURR_STAGE->target_time))
	{
		aliens_init();
		spawn_boss();
		boss_spawned = true;
	}

	if (boss_spawned && !is_boss_alive())
	{
		if (stage_num < 2)	//3�������� ����
		{
			stage_num++;
			boss_spawned = false;
			for (int i = 0; i < ALIENS_N; ++i)
			{
				if (!aliens[i].used) continue;
				aliens[i].used = false;
			}
			shots_init();
		}
		else
		{
			//Ŭ���� UI �����ϴ� �ڵ带 ����
			//���� �߰�
		}
	}
}