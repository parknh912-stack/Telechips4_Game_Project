#include "Core.h"
#include "Sprites.h"
#include "Item/Item.h"
/* --- Sprites --- */

// 0: ���ٸ� �ϴ� �� ( � ), 1: 0���� ������ �� ������ ü���� ����,  2: 0������ �������� ����ü �߻� 3: ����   
// 1������ enemyred2��
const int ALIEN_W[] = { 101, 104, 103, 800 };
const int ALIEN_H[] = { 84, 84, 84, 552 };
const int ALIEN_R[] = { 42, 42, 42, 270 };
SPRITES sprites;

ALLEGRO_BITMAP* sprite_grab(int x, int y, int w, int h)
{
    ALLEGRO_BITMAP* sprite = al_create_sub_bitmap(sprites._sheet, x, y, w, h);
    must_init(sprite, "sprite grab");
    return sprite;
}

//�ۼ��� : �ڳ���
void sprites_init()
{
    sprites._sheet = al_load_bitmap("sheet.png");
    must_init(sprites._sheet, "spritesheet");

    sprites.ship = sprite_grab(444, 91, 91, 91);    //"ufoBlue.png" x="444" y="91" width="91" height="91"/>

    sprites.ship_shot[0] = sprite_grab(434, 325, 48, 46); //"laserBlue09.png" x="434" y="325" width="48" height="46"
    sprites.ship_shot[1] = sprite_grab(698, 795, 38, 37); //"laserBlue11.png" x="698" y="795" width="38" height="37"

    sprites.life = sprite_grab(843, 977, 13, 37);//0327 UI 
    sprites.life_bar = sprite_grab(0, 0, 222, 38);//0327 UI 

    sprites.alien[0] = sprite_grab(224, 748, ALIEN_METEOR_W, ALIEN_METEOR_H); // "meteorGrey_big1.png" x="224" y="748" width="101" height="84"/>
    sprites.alien[1] = sprite_grab(120, 520, ALIEN_FAST_W, ALIEN_FAST_H); // "enemyRed2.png" x="120" y="520" width="104" height="84"/>
    sprites.alien[2] = sprite_grab(224, 496, ALIEN_SHOOTER_W, ALIEN_SHOOTER_H); // "enemyGreen3.png" x="224" y="496" width="103" height="84"/>
    sprites.alien[3] = al_load_bitmap("spaceStation_026.png");
    must_init(sprites.alien[3], "boss");

    /*sprites.alien[4] = sprite_grab(0, 21, ALIEN_THICCBOI_W, ALIEN_THICCBOI_H);
    sprites.alien[5] = sprite_grab(0, 21, ALIEN_THICCBOI_W, ALIEN_THICCBOI_H);*/

    sprites.alien_shot = sprite_grab(310, 982, 41, 41); //"turretBase_big.png" x="310" y="982" width="41" height="41"/>

    sprites.explosion[0] = sprite_grab(33, 10, 9, 9);
    sprites.explosion[1] = sprite_grab(43, 9, 11, 11);
    sprites.explosion[2] = sprite_grab(46, 21, 17, 18);
    sprites.explosion[3] = sprite_grab(46, 40, 17, 17);

    sprites.sparks[0] = sprite_grab(34, 0, 10, 8);
    sprites.sparks[1] = sprite_grab(45, 0, 7, 8);
    sprites.sparks[2] = sprite_grab(54, 0, 9, 8);

    //0327 �ڳ���
    sprites.item[ITEM_TYPE_NONE];   //NONE�̶� ����
    sprites.item[ITEM_TYPE_HEAL_POTION] = sprite_grab(573, 989, 22, 21); //"pill_green.png" x="573" y="989" width="22" height="21
    sprites.item[ITEM_TYPE_BOMB] = sprite_grab(778, 527, 31, 30); //"star_silver.png" x = "778" y = "527" width = "31" height = "30"
    sprites.item[ITEM_TYPE_EXP] = sprite_grab(696, 329, 34, 33); //powerupBlue.png" x="696" y="329" width="34" height="33"
    sprites.item[ITEM_TYPE_BARRIER] = sprite_grab(797, 113, 30, 30); //shield_gold.png" x="797" y="113" width="30" height="30"/>
    sprites.item[ITEM_TYPE_RANDOM_STAT_CHANGE] = sprite_grab(505, 898, 91, 91); //"ufoYellow.png" x="505" y="898" width="91" height="91"/>

    //0327 �ڳ���
    sprites.barrier = sprite_grab(0, 412, 133, 108); //shield1.png" x="0" y="412" width="133" height="108"/>
}

void sprites_deinit()
{
    al_destroy_bitmap(sprites.ship);

    al_destroy_bitmap(sprites.ship_shot[0]);
    al_destroy_bitmap(sprites.ship_shot[1]);

    al_destroy_bitmap(sprites.life);
    al_destroy_bitmap(sprites.life_bar);    //UI

    al_destroy_bitmap(sprites.alien[0]);
    al_destroy_bitmap(sprites.alien[1]);
    al_destroy_bitmap(sprites.alien[2]);
    al_destroy_bitmap(sprites.alien[3]);

    al_destroy_bitmap(sprites.alien_shot);

    al_destroy_bitmap(sprites.explosion[0]);
    al_destroy_bitmap(sprites.explosion[1]);
    al_destroy_bitmap(sprites.explosion[2]);
    al_destroy_bitmap(sprites.explosion[3]);

    al_destroy_bitmap(sprites.sparks[0]);
    al_destroy_bitmap(sprites.sparks[1]);
    al_destroy_bitmap(sprites.sparks[2]);

    al_destroy_bitmap(sprites.item[ITEM_TYPE_NONE]);
    al_destroy_bitmap(sprites.item[ITEM_TYPE_HEAL_POTION]);
    al_destroy_bitmap(sprites.item[ITEM_TYPE_BOMB]);
    al_destroy_bitmap(sprites.item[ITEM_TYPE_EXP]);
    al_destroy_bitmap(sprites.item[ITEM_TYPE_BARRIER]);
    al_destroy_bitmap(sprites.item[ITEM_TYPE_RANDOM_STAT_CHANGE]);
    al_destroy_bitmap(sprites.barrier);

    al_destroy_bitmap(sprites._sheet);
}