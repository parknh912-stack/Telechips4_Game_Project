#include "../Core.h"
#include "../Display.h"
#include "../UI/UI.h"
#include "../Keyboard.h"
#include "../Sprites.h"
#include "../Player_Enemy/Player_Enemy.h"
#include "../Rank.h"

// --- stars ---
STAR stars[STARS_N];

void stars_init()//0328 �躴��
{
    for (int i = 0; i < STARS_N; i++)
    {
        stars[i].y = between_f(0, BUFFER_H);
        stars[i].speed = between_f(STAR_SPEED_MIN, STAR_SPEED_MAX);//0328 �躴��
    }
}
void stars_update()//0328 �躴��
{
    for (int i = 0; i < STARS_N; i++)//0328 �躴��
    {
        stars[i].y += stars[i].speed;//0328 �躴��
        if (stars[i].y >= BUFFER_H)//0328 �躴��
        {
            stars[i].y = 0;//0328 �躴��
            stars[i].speed = between_f(STAR_SPEED_MIN, STAR_SPEED_MAX);//0328 �躴��
        }
    }
}

void stars_draw()
{
    float star_x = STAR_START;//0328 �躴��
    for (int i = 0; i < STARS_N; i++)//0328 �躴��
    {
        float l = stars[i].speed;//0328 �躴��
        al_draw_pixel(star_x, stars[i].y, al_map_rgb_f(rand() % 255, rand() % 255, rand() % 255));//0328 �躴��
        star_x += STAR_SPACING;//0328 �躴��
    }
}

// --- hud ---
ALLEGRO_FONT* font;
ALLEGRO_FONT* bold_font;//0327 �躴�� ����� ū ��Ʈ
ALLEGRO_FONT* compcolor_font;//�躴�� ������ ��Ʈ
long score_display;
double stage_alert_timer = -1.0;
double boss_alert_timer = -1.0;

void hud_init()//0328 �躴��
{
    al_init_font_addon();//0327 �躴�� �������� : �۾� ũ�⸦ Ű�����ϴ�.
    al_init_ttf_addon();//0328 �躴��
    font = al_load_ttf_font("PressStart2P.ttf", FONT_SIZE_NORMAL, 0);//0328 �躴��
    bold_font = al_load_ttf_font("PressStart2P.ttf", FONT_SIZE_TITLE, 0);//0328 �躴��
    compcolor_font = al_load_ttf_font("PressStart2P.ttf", FONT_SIZE_TITLE, 0);//0328 �躴��
    must_init(font, "font");
    score_display = 0;
}

void hud_deinit()
{
    al_destroy_font(font);
}

void hud_update()
{
    if (frames % 2)
        return;

    for (long i = 5; i > 0; i--)
    {
        long diff = 1 << i;
        if (score_display <= (score - diff))
            score_display += diff;
    }
}

void hud_draw()
{
    al_draw_textf(font, al_map_rgb_f(1, 1, 1), HUD_SCORE_X, HUD_SCORE_Y, 0, "%06ld", score_display);//0328 �躴��

    float hp_ratio = (float)ship.curr_lifes / PLAYER_MAX_HP_BASE;//0328 �躴��
    if (hp_ratio < 0) hp_ratio = 0;

    al_draw_textf(font, al_map_rgb_f(1, 1, 1), HUD_LEVEL_X, HUD_LEVEL_Y, 0, "Level: %02d", level);//0328 �躴��
    //���� �������� ���
    al_draw_textf(font, al_map_rgb_f(1, 1, 1), 5, 120, 0, "stage: %02d", stage_num + 1);
    al_draw_textf(font, al_map_rgb_f(1, 1, 1), 5, 150, 0, "x : %d", (int)ship.cx);
    al_draw_textf(font, al_map_rgb_f(1, 1, 1), 5, 180, 00, "y : %d", (int)ship.cy);
    al_draw_textf(font, al_map_rgb_f(1, 1, 1), 5, 210, 00, "sec : %d", (frames / 60));

    int spacing = LIFE_W + 1;
    al_draw_scaled_bitmap(sprites.life_bar, 0, 0, LIFE_BAR_SRC_W, LIFE_BAR_SRC_H, spacing, HUD_LIFE_BAR_Y, (LIFE_W + 2) * ship.max_lifes, LIFE_BAR_SRC_H, 0);//0328�躴��
    for (int i = 0; i < ship.curr_lifes; i++)
        al_draw_bitmap(sprites.life, HUD_LIFE_ICON_OFFSET_X + (i * spacing), HUD_LIFE_BAR_Y, 0);//0328 �躴��

    // 0330 ������ - ���� ��Ÿ���ٰ� ȭ�鿡 �޽��� 2�ʰ� ǥ��
    if (is_boss_alive() && boss_alert_timer >= 0.0 && (al_get_time() - boss_alert_timer < 2.0))
        al_draw_text(
            bold_font,
            al_map_rgb_f(1.0, 0.0, 0.0),
            BUFFER_W / 2, BUFFER_H / 2,
            ALLEGRO_ALIGN_CENTER,
            "!!! A L E R T !!!"
        );

    // 0330 ������ - �� ��° ���������� �����ߴٰ� 2�ʰ� ȭ�鿡 �޽��� ǥ��
    if (stage_alert_timer >= 0.0 && (al_get_time() - stage_alert_timer < 2.0))
    {
        al_draw_textf(
            bold_font,
            al_map_rgb_f(1.0, 1.0, 1.0),
            BUFFER_W / 2, BUFFER_H / 2,
            ALLEGRO_ALIGN_CENTER,
            "=== S T A G E   %02d ===",
            stage_num + 1
        );
    }
}


// --- UI ---

// �ۼ���: �躴��
ALLEGRO_BITMAP* ui_sheet = NULL;
int current_menu_selection = 0;

void ui_init()
{
    ui_sheet = al_load_bitmap("ui_sheet.png");
    must_init(ui_sheet, "ui_sheet");
}

void ui_deinit()
{
    if (ui_sheet)
    {
        al_destroy_bitmap(ui_sheet);
        ui_sheet = NULL;
    }
}

void draw_ui_element(int sx, int sy, int sw, int sh, float dx, float dy, float real_width, float real_height)
{
    al_draw_scaled_bitmap(ui_sheet, sx, sy, sw, sh, dx, dy, real_width, real_height, 0);
}

void draw_bold_text(ALLEGRO_FONT* font, ALLEGRO_COLOR main_color, ALLEGRO_COLOR outline_color, float x, float y, int flags, int thickness, const char* text)//0328 �躴�� ����ü ����� ���� �Լ��� ����
{
    //�׵θ�
    al_draw_text(font, outline_color, x + thickness, y, flags, text);//0328 �躴��
    al_draw_text(font, outline_color, x - thickness, y, flags, text);//0328 �躴��
    al_draw_text(font, outline_color, x, y + thickness, flags, text);//0328 �躴��
    al_draw_text(font, outline_color, x, y - thickness, flags, text);//0328 �躴��
    //����
    al_draw_text(font, main_color, x, y, flags, text);//0328 �躴��
}

void draw_menu_ui(MENU* m, const char* title, int button_y, float wanted_width, float wanted_height, ALLEGRO_FONT* fonto)
{
    draw_ui_element(UI_PANEL_BLUE_X, UI_PANEL_BLUE_Y, UI_PANEL_W, UI_PANEL_H, m->x - wanted_width / 2, m->y - wanted_height / 2, wanted_width, wanted_height);

    if (title)
    {
        draw_bold_text(fonto, COLOR_TITLE, COLOR_BLACK, m->x, (m->y) / 1.7, ALLEGRO_ALIGN_CENTER, 2, title);//0328 �躴��
    }

    for (int i = 0; i < m->item_count; i++)
    {
        float btn_w = m->width * 0.9f;
        float btn_h = 40.0f;
        float btn_x = m->x - (btn_w / 2);//���� �����Դϴ�. ���� yes no�� �������� �� ������ �غ��߰پ��.
        float btn_y = m->y - button_y + (i * 50);

        int sx, sy, sh;
        if (m->selected == i)
        {
            sx = UI_BTN_BLUE_P_X; sy = UI_BTN_BLUE_P_Y; sh = UI_BTN_P_H;
            btn_y += MENU_BTN_PRESSED_OFFSET;

            float cursor_w = MENU_CUR_SIZE;//0328 �躴�� - �޴����� Ŀ��
            float cursor_h = MENU_CUR_SIZE;//0328 �躴�� - �޴����� Ŀ��
            float cursor_x = btn_x - cursor_w - 15.0f;//0328 �躴�� - �޴����� Ŀ��
            float cursor_y = btn_y + (btn_h / 2.0f) - (cursor_h / 2.0f);//0328 �躴�� - �޴����� Ŀ��
            draw_ui_element(MENU_SEL_POS_X, MENU_SEL_POS_Y, MENU_SEL_WIDTH, MENU_SEL_HEIGHT, cursor_x, cursor_y, cursor_w, cursor_h);//0328 �躴�� - �޴����� Ŀ��
        }
        else
        {
            sx = UI_BTN_BLUE_X; sy = UI_BTN_BLUE_Y; sh = UI_BTN_H;
        }

        draw_ui_element(sx, sy, UI_BTN_W, sh, btn_x, btn_y, btn_w, btn_h);


        draw_bold_text(font, COLOR_WHITE, COLOR_BLACK, m->x, btn_y + 12, ALLEGRO_ALIGN_CENTER, 1, m->items[i]);//0328 �躴��

    }
}

void menu_input_update(int item_count)
{
    if (key[ALLEGRO_KEY_UP] & KEY_SEEN)
    {
        current_menu_selection--;
        if (current_menu_selection < 0)
        {
            current_menu_selection = item_count - 1;
        }
    }
    if (key[ALLEGRO_KEY_DOWN] & KEY_SEEN)
    {
        current_menu_selection++;
        if (current_menu_selection >= item_count)
        {
            current_menu_selection = 0;
        }
    }
}

void ui_draw_main_menu()
{
    MENU m = { BUFFER_W / 2, BUFFER_H / 2, 250, 300, {"Start Game", "How to play", "Ranking", "Exit"}, 4, current_menu_selection };//0328 �躴�� howtoplay �߰�
    draw_menu_ui(&m, "- SPACE SURVIVOR -", UI_BTN_POS_Y_MID, UI_PANEL_SIZE_W, UI_PANEL_SIZE_H_L, bold_font);
}

void ui_draw_pause_menu()
{
    MENU m = { BUFFER_W / 2, BUFFER_H / 2, 180, 200, {"Resume", "Main Menu"}, 2, current_menu_selection };
    draw_menu_ui(&m, "PAUSED", UI_BTN_POS_Y_MID, UI_PANEL_SIZE_W, UI_PANEL_SIZE_H_M, bold_font);
}

void ui_draw_gameover_menu()
{
    MENU m = { BUFFER_W / 2, BUFFER_H / 2, 200, 250, {"Restart", "Ranking","Main Menu"}, 3, current_menu_selection };
    draw_menu_ui(&m, "GAME OVER", UI_BTN_POS_Y_MID, UI_PANEL_SIZE_W, UI_PANEL_SIZE_H_M, bold_font);
}

void ui_draw_rank_menu()
{
    // 1. �⺻ �޴� �� �׸��� (Back ��ư ����)
    MENU m = { BUFFER_W / 2, BUFFER_H / 2, 220, 300, {"Back"}, 1, current_menu_selection };
    draw_menu_ui(&m, "LEADERBOARD", UI_BTN_POS_Y_LOW, UI_PANEL_SIZE_W_L, UI_PANEL_SIZE_H_L, bold_font);

    // 2. ��ŷ ������ ��� (���� 5��)
    float start_y = m.y - (m.height / 2) + RANK_TITLE_OFFSET_Y; // 0328 �躴��
    for (int i = 0; i < MAX_RANKING; i++)
    {
        // ���� �� �̸� (���� ����)
        //0328 �躴�� �� �� �� �޴� �� ���� ����
        float left_x = m.x - RANK_POS_X_OFFSET; //0328 �躴��
        float right_x = m.x + RANK_POS_X_OFFSET; //0328 �躴��
        float line_y = start_y + (i * RANK_LINE_SPACING); //0328 �躴��

        if (i == 0)
        {
            al_draw_textf(font, COLOR_GOLD, left_x, line_y, ALLEGRO_ALIGN_LEFT, "%d. %-10s", i + 1, ranking[i].username);//0328 �躴��
        }
        else if (i == 1)
        {
            al_draw_textf(font, COLOR_SILVER, left_x, line_y, ALLEGRO_ALIGN_LEFT, "%d. %-10s", i + 1, ranking[i].username);//0328 �躴��
        }
        else if (i == 2)
        {
            al_draw_textf(font, COLOR_BRONZE, left_x, line_y, ALLEGRO_ALIGN_LEFT, "%d. %-10s", i + 1, ranking[i].username);//0328 �躴��
        }
        else al_draw_textf(font, COLOR_BLACK, left_x, line_y, ALLEGRO_ALIGN_LEFT, "%d. %-10s", i + 1, ranking[i].username);//0328 �躴��

        al_draw_textf(font, COLOR_YELLOW, right_x, line_y, ALLEGRO_ALIGN_RIGHT, "%ld", ranking[i].score);//0328 �躴��
    }
}

void ui_draw_input_name_menu()
{
    // 1. ��� �� �׸���
    MENU m = { BUFFER_W / 2, BUFFER_H / 2, 220, 160, {"Save (Enter)"}, 1, current_menu_selection };
    draw_menu_ui(&m, "NEW HIGH SCORE!", UI_BTN_POS_Y_LOW, UI_PANEL_SIZE_W, UI_PANEL_SIZE_H_M, bold_font);

    float input_w = 320.0f; //0328 �躴�� �Է�â �ʺ�
    float input_h = 50.0f; //0328 �躴�� �Է�â ����
    float input_x = m.x - (input_w / 2); //0328 �躴�� �Է�â �ʺ� ���� ��ġ
    float input_y = m.y - (input_h / 2); //0328 �躴�� �Է�â ���̿� ���� ��ġ

    // 2. �Է� �ڽ� ���� (��ư �� �� ����)
    draw_ui_element(0, 0, INPUT_BOX_SRC_W, INPUT_BOX_SRC_H, input_x, input_y, input_w, input_h);//0328 �躴��

    // ���� �Է� ���� �̸� ���
    al_draw_text(font, COLOR_BLACK, m.x, m.y - 6, ALLEGRO_ALIGN_CENTER, player_name);//0328 �躴��


}

// �ۼ���: ������
void ui_draw_level_up_menu()
{
    MENU m =  { BUFFER_W / 2, BUFFER_H / 2,
                300, 500,
                { "ATK + 2 ", "BULLET + 1", "ATK SPD + 20%", "SPD + 10%", "MAX LIFE + 10%", "HEAL"}, 
                6,
                current_menu_selection};
    
    draw_menu_ui(&m, "LEVEL UP!!!", UI_BTN_POS_Y_HI, UI_PANEL_SIZE_W, UI_PANEL_SIZE_H_L, bold_font);
    
}

void ui_draw_h2p_menu()//0328 �躴��
{
    int extra_y = 50;
    MENU m = { BUFFER_W / 2, BUFFER_H / 2, 220, 300, {"Back"}, 1, current_menu_selection };
    draw_menu_ui(&m, "ABOUT", UI_BTN_POS_Y_LOW - extra_y, UI_PANEL_SIZE_W_VL, UI_PANEL_SIZE_H_L + 100, bold_font);
    draw_bold_text(font, COLOR_WHITE, COLOR_BLACK, m.x, m.y - 6, ALLEGRO_ALIGN_CENTER, 1, "This is game");//0328 �躴��
    al_draw_bitmap(sprites.item[1], m.x / 2, m.y - 6, ALLEGRO_ALIGN_LEFT);
    al_draw_bitmap(sprites.item[2], m.x / 2, m.y - 6 + 25, ALLEGRO_ALIGN_LEFT);
    al_draw_bitmap(sprites.item[3], m.x / 2, m.y - 6 + 50, ALLEGRO_ALIGN_LEFT);
    al_draw_bitmap(sprites.item[4], m.x / 2, m.y - 6 + 75, ALLEGRO_ALIGN_LEFT);

    draw_bold_text(font, COLOR_WHITE, COLOR_BLACK, m.x, m.y - 6 + 25, ALLEGRO_ALIGN_CENTER, 1, "THIS IS RED PILL");//0328 �躴��
    draw_bold_text(font, COLOR_WHITE, COLOR_BLACK, m.x, m.y - 6 + 2 * 25, ALLEGRO_ALIGN_CENTER, 1, "THIS IS BLUE PILL");//0328 �躴��
}

// �ۼ���: 0330 ������ - ���� �޴�
void ui_draw_ending_menu(void)
{
    MENU m = {
        BUFFER_W / 2, BUFFER_H / 2,
        200, 400,
        { "Record Your Score", "Return To Menu" },
        2,
        current_menu_selection
    };
    
    draw_menu_ui(&m, "GAME CLEAR!!!", UI_BTN_POS_Y_HI, UI_PANEL_SIZE_W, UI_PANEL_SIZE_H_L, bold_font);
}

