#ifndef _BACKGROUND_H_
#define _BACKGROUND_H_
//0329 �ڳ���

extern ALLEGRO_BITMAP* BG_sheet[];

void backgound_init();
void background_draw();
void background_deinit();

#endif