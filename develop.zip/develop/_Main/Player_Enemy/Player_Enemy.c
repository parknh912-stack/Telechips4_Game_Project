#include "../Core.h"
#include "Player_Enemy.h"

#include "../Display.h"
#include "../Keyboard.h"
#include "../Sprites.h"
#include "../Audio.h"
#include "../Fx.h"
#include "../Item/Item.h"
#include "../Stage/Stage.h"

/* --- shot --- */

SHOT shots[SHOTS_N];

void shots_init()
{
    for (int i = 0; i < SHOTS_N; i++)
        shots[i].used = false;
}

//�ۼ��� : �ڳ���
bool shots_add(bool is_ship, bool straight, float x, float y, int shot_count)
{
    //sound ����
    al_play_sample(
        sample_shot,
        0.3,
        0,
        is_ship ? 1.0 : between_f(1.5, 1.6),
        ALLEGRO_PLAYMODE_ONCE,
        NULL
    );

    // ���� ����
    float speed = is_ship ? 5.0f : 5.0f;

    float spread_gap = 0.2f;
    float target_x, target_y;
    bool has_target = false;
    bool has_shot_created_success = false;
    //shot�� �Ʊ������� ���������� Ȯ�� �� target ��ǥ ����
    if (is_ship)
    {
        int target_idx = get_closet_enemy();    //���� ����� ���� �����ϴ� �Լ� �� ���
        if (target_idx != -1)
        {
            target_x = aliens[target_idx].cx;
            target_y = aliens[target_idx].cy;
            has_target = true;
        }
        else
            return false;
    }
    else //alien
    {
        if (straight)
        {
            target_x = ship.cx;
            target_y = ship.cy;
            has_target = true;
        }
    }

    if (has_target)
    {
        float dx = target_x - x;
        float dy = target_y - y;

        if (dx > (MAP_WIDTH / 2)) dx -= MAP_WIDTH;
        else if (dx < -(MAP_WIDTH / 2)) dx += MAP_WIDTH;

        if (dy > (MAP_HEIGHT / 2)) dy -= MAP_HEIGHT;
        else if (dy < -(MAP_HEIGHT / 2)) dy += MAP_HEIGHT;

        float base_angle = atan2f(dy, dx);
        float start_angle = base_angle - ((shot_count - 1) / 2.0f) * spread_gap;

        for (int i = 0; i < shot_count; ++i)
        {
            float curr_angle = start_angle + i * spread_gap;
            float dx = cos(curr_angle) * speed;
            float dy = sin(curr_angle) * speed;
            if (shots_create_instance(is_ship, x, y, dx, dy))
                has_shot_created_success = true;
        }
    }
    else if (!is_ship && !straight)
    {
        if (shots_create_instance(false, x, y, between_f(-2.0f, 2.0f), between_f(-2.0f, 2.0f)))
            has_shot_created_success = true;
    }
    return has_shot_created_success;
}

bool shots_create_instance(bool is_ship, float x, float y, float dx, float dy)
{
    if (dx == 0 && dy == 0)
        return true;
    for (int i = 0; i < SHOTS_N; ++i)
    {
        if (shots[i].used) continue;
        shots[i].ship = is_ship;
        shots[i].used = true;
        shots[i].frame = 0;

        shots[i].x = x - (is_ship ? (SHIP_SHOT_W / 2) : (ALIEN_SHOT_W / 2));
        shots[i].y = y - (is_ship ? 0 : (ALIEN_SHOT_H / 2));
        shots[i].dx = dx;
        shots[i].dy = dy;

        return true;
    }
    return false;
}


// �ۼ��� : �ڳ���
/* --- ���� ����� �� �ĺ� --- */
int get_closet_enemy()
{
    int target_idx = -1;
    float min_distance = 1e10f;

    for (int i = 0; i < ALIENS_N; ++i)
    {
        if (!aliens[i].used) continue;

        float dx = aliens[i].cx - ship.cx;
        float dy = aliens[i].cy - ship.cy;

        if (dx > (MAP_WIDTH / 2)) dx -= MAP_WIDTH;
        else if (dx < -(MAP_WIDTH / 2)) dx += MAP_WIDTH;

        if (dy > (MAP_HEIGHT / 2)) dy -= MAP_HEIGHT;
        else if (dy < -(MAP_HEIGHT / 2)) dy += MAP_HEIGHT;

        float square_distance = (dx * dx) + (dy * dy);
        if (min_distance > square_distance)
        {
            min_distance = square_distance;
            target_idx = i;
        }
    }
    return target_idx;
}

//�ۼ��� : �ڳ���
void shots_update()
{
    for (int i = 0; i < SHOTS_N; i++)
    {
        if (!shots[i].used)
			continue;

		shots[i].x += shots[i].dx;
		shots[i].y += shots[i].dy;

		// �ۼ��� : �ڳ���
		// ���Ѹ� ������ ���Ͽ�, ������°� ����
		if (shots[i].x > MAP_WIDTH)  shots[i].x = 0;
		if (shots[i].x < 0)          shots[i].x = MAP_WIDTH;
		if (shots[i].y > MAP_HEIGHT) shots[i].y = 0;
		if (shots[i].y < 0)          shots[i].y = MAP_HEIGHT;

        shots[i].frame++;
    }
}

//�ۼ��� : �ڳ���
bool shots_collide(bool ship, float cx, float cy, float w, float h)
{
    for (int i = 0; i < SHOTS_N; i++)
    {
        if (!shots[i].used)
            continue;

        // don't collide with one's own shots
        if (shots[i].ship == ship)
            continue;

        int sw, sh;
        if (ship)
        {
            sw = ALIEN_SHOT_W;
            sh = ALIEN_SHOT_H;
            // �ۼ��� : �ڳ���
            /* �� -> �Ʊ��� ���� ���� �浹 */
            if (collide_circle(cx, cy, SHIP_R, shots[i].x, shots[i].y, ALIEN_SHOT_R))
            {
                fx_add(true, shots[i].x + (sw / 2.0f), shots[i].y + (sh / 2.0f));
                shots[i].used = false;
                return true;
            }

        }
        else
        {
            sw = SHIP_SHOT_W;
            sh = SHIP_SHOT_H;
            /* �Ʊ� -> ���� ���� AABB �浹 (���� ���� �浹�� �ٲ� ����) */
            if (collide(cx, cy, cx + w, cy + h, shots[i].x, shots[i].y, shots[i].x + sw, shots[i].y + sh))
            {
                fx_add(true, shots[i].x + (sw / 2.0f), shots[i].y + (sh / 2.0f));
                shots[i].used = false;
                return true;
            }
        }

    }

    return false;
}

void shots_draw()
{
    for (int i = 0; i < SHOTS_N; i++)
    {
        if (!shots[i].used)
            continue;

        int frame_display = (shots[i].frame / 2) % 2;
        // �ۼ��� : �ڳ���
        /*����; �Ѿ� ũ�� ����*/
        ALLEGRO_BITMAP* current_shot = sprites.ship_shot[frame_display];
        int sw = al_get_bitmap_width(current_shot);
        int sh = al_get_bitmap_height(current_shot);

        if (shots[i].ship)
        {
            al_draw_scaled_bitmap(sprites.ship_shot[frame_display],
                0, 0, sw, sh,
                shots[i].x - (SHIP_SHOT_W / 2),
                shots[i].y - (SHIP_SHOT_H / 2),
                SHIP_SHOT_W, SHIP_SHOT_H,
                0);

            if (shots[i].y > MAP_WIDTH - 640)
                al_draw_scaled_bitmap(sprites.ship_shot[frame_display],
                    0, 0, sw, sh,
                    shots[i].x - (SHIP_SHOT_W / 2) - MAP_WIDTH,
                    shots[i].y - (SHIP_SHOT_H / 2),
                    SHIP_SHOT_W, SHIP_SHOT_H,
                    0);
            if (shots[i].x < 640)
                al_draw_scaled_bitmap(sprites.ship_shot[frame_display],
                    0, 0, sw, sh,
                    shots[i].x - (SHIP_SHOT_W / 2) + MAP_WIDTH,
                    shots[i].y - (SHIP_SHOT_H / 2),
                    SHIP_SHOT_W, SHIP_SHOT_H,
                    0);
            if (shots[i].y > MAP_HEIGHT - 640)
                al_draw_scaled_bitmap(sprites.ship_shot[frame_display],
                    0, 0, sw, sh,
                    shots[i].x - (SHIP_SHOT_W / 2),
                    shots[i].y - (SHIP_SHOT_H / 2) - MAP_HEIGHT,
                    SHIP_SHOT_W, SHIP_SHOT_H,
                    0);
            if (shots[i].y < 640)
                al_draw_scaled_bitmap(sprites.ship_shot[frame_display],
                    0, 0, sw, sh,
                    shots[i].x - (SHIP_SHOT_W / 2),
                    shots[i].y - (SHIP_SHOT_H / 2) + MAP_HEIGHT,
                    SHIP_SHOT_W, SHIP_SHOT_H,
                    0);
        }

        else // alien
        {
            ALLEGRO_COLOR tint =
                frame_display
                ? al_map_rgb_f(1, 0, 0)
                : al_map_rgb_f(0.9, 0, 0)
                ;
            // �ۼ��� : �ڳ���
            // �۰� �ٲ�
            al_draw_tinted_scaled_bitmap(sprites.alien_shot, tint,
                0, 0, 41, 41,
                shots[i].x, shots[i].y,
                ALIEN_SHOT_W, ALIEN_SHOT_H,
                0);

            if (shots[i].y > MAP_WIDTH - 640)
                al_draw_tinted_scaled_bitmap(sprites.alien_shot, tint,
                    0, 0, 41, 41,
                    shots[i].x - MAP_WIDTH, shots[i].y,
                    ALIEN_SHOT_W, ALIEN_SHOT_H,
                    0);
            if (shots[i].x < 640)
                al_draw_tinted_scaled_bitmap(sprites.alien_shot, tint,
                    0, 0, 41, 41,
                    shots[i].x + MAP_WIDTH, shots[i].y,
                    ALIEN_SHOT_W, ALIEN_SHOT_H,
                    0);
            if (shots[i].y > MAP_HEIGHT - 640)
                al_draw_tinted_scaled_bitmap(sprites.alien_shot, tint,
                    0, 0, 41, 41,
                    shots[i].x, shots[i].y - MAP_WIDTH,
                    ALIEN_SHOT_W, ALIEN_SHOT_H,
                    0);
            if (shots[i].y < 640)
                al_draw_tinted_scaled_bitmap(sprites.alien_shot, tint,
                    0, 0, 41, 41,
                    shots[i].x, shots[i].y + MAP_WIDTH,
                    ALIEN_SHOT_W, ALIEN_SHOT_H,
                    0);
        }
    }
}

/* --- Player --- */

SHIP ship;

// �ۼ��� : �ڳ���
// ���� ��ü������ ����Ǿ���.
void ship_init()
{
    //0330
    ship.x = (MAP_WIDTH / 2) - (SHIP_W / 2);
    ship.y = (MAP_HEIGHT / 2) - (SHIP_H / 2);
    ship.cx = ship.x + (SHIP_W / 2);
    ship.cy = ship.y + (SHIP_H / 2);

    ship.speed = 4.0f;          //�̵��ӵ�, ��������
    ship.fire_rate = 1.0f;      //�ʴ� ���� Ƚ�� (��������)
    ship.shot_timer = 60;       //shot_timer
    ship.damage = 5;           //������, int      (��������)
    ship.shot_count = 1;        //����ü �� (Ȧ������)
    ship.max_lifes = 100;       //�ִ� ü��
    ship.curr_lifes = 100;      //���� ü��
    ship.barrier = false;

    ship.invincible_timer = 3;  //�����ð�
}

void ship_update()
{
    if (ship.curr_lifes < 0)
    {
        current_state = STATE_GAMEOVER;
        ship_init();
        return;
    }

    if (key[ALLEGRO_KEY_LEFT])
        ship.x -= ship.speed;
    if (key[ALLEGRO_KEY_RIGHT])
        ship.x += ship.speed;
    if (key[ALLEGRO_KEY_UP])
        ship.y -= ship.speed;
    if (key[ALLEGRO_KEY_DOWN])
        ship.y += ship.speed;

	//if (ship.x < 0)
	//    ship.x = 0;
	//if (ship.y < 0)
	//    ship.y = 0;

	//if (ship.x > SHIP_MAX_X)
	//    ship.x = SHIP_MAX_X;
	//if (ship.y > SHIP_MAX_Y)
	//    ship.y = SHIP_MAX_Y;

    //0330
    // ���� ��ǥ ����
    if (ship.x < 0)
        ship.x = MAP_WIDTH;
    else if (ship.x > MAP_WIDTH)
        ship.x = 0;

    // ���� ��ǥ ����
    if (ship.y < 0)
        ship.y = MAP_HEIGHT;
    else if (ship.y > MAP_HEIGHT)
        ship.y = 0;


    ship.cx = ship.x + (SHIP_W / 2);
    ship.cy = ship.y + (SHIP_H / 2);

    if (ship.invincible_timer)
        ship.invincible_timer--;
    else
    {
        if (shots_collide(true, ship.cx, ship.cy, SHIP_W, SHIP_H))
        {
            fx_add(false, ship.cx, ship.cy);
            fx_add(false, ship.cx + 4, ship.cy + 2);
            fx_add(false, ship.cx - 2, ship.cy - 4);
            fx_add(false, ship.cx + 1, ship.cy - 5);
            if (!ship.barrier)
            {
                ship.curr_lifes--;
                ship.invincible_timer = 1;
            }
            else
            {
                ship.invincible_timer = 180;
                ship.barrier = false;
            }
        }

        /* ���� ���� �浹 �ÿ��� */
        if (ship_collide(ship.cx, ship.cy))
        {
            //fx_add(false, ship.cx, ship.cy);
            //fx_add(false, ship.cx + 4, ship.cy + 2);
            //fx_add(false, ship.cx - 2, ship.cy - 4);
            //fx_add(false, ship.cx + 1, ship.cy - 5);
            if (!ship.barrier)
            {
                ship.curr_lifes--;
                ship.invincible_timer = 1;
            }
            else
            {
                ship.invincible_timer = 180;
                ship.barrier = false;
            }
        }
    }



    // �ۼ��� : �ڳ���
    // ���� �ð����� �ڵ� ����
    if (ship.shot_timer)
        ship.shot_timer--;
    if (ship.shot_timer <= 0) {

        shots_add(true, false, ship.cx, ship.cy, ship.shot_count);
        ship.shot_timer = 60.0 / ship.fire_rate;
    }
    item_collide(ship.cx, ship.cy);
}

void ship_draw()
{
    if (ship.curr_lifes < 0)
        return;
    if (((ship.invincible_timer / 2) % 3) == 1)
        return;
    // �ۼ��� : �ڳ���
    // ũ�� �ٸ��� �ٲ�
    if (ship.barrier) {
        al_draw_scaled_bitmap(sprites.barrier,
            0, 0,
            al_get_bitmap_width(sprites.barrier),
            al_get_bitmap_height(sprites.barrier),
            ship.cx - (ITEMS_BARRIER_W / 2), ship.cy - (ITEMS_BARRIER_H / 2),
            ITEMS_BARRIER_W, ITEMS_BARRIER_H,
            0);
    }
    //al_draw_scaled_bitmap(sprites.ship,
    //    0, 0,
    //    91, 91,
    //    ship.x, ship.y,
    //    SHIP_W, SHIP_H,
    //    0);

    al_draw_scaled_bitmap(sprites.ship,
        0, 0,                                // ���� �̹��� ������
        91, 91,                              // ���� �̹��� ũ��
        (BUFFER_W / 2) - (SHIP_W / 2),           // [����] ȭ�� ���� �߾�
        (BUFFER_H / 2) - (SHIP_H / 2),            // [����] ȭ�� ���� �߾�
        SHIP_W, SHIP_H,                      // ȭ�鿡 �׷��� ũ��
        0);
    //al_draw_bitmap(sprites.ship, ship.x, ship.y, 0);
}

bool ship_collide(int cx, int cy)
{
    for (int i = 0; i < ALIENS_N; ++i)
    {
        if (!aliens[i].used) continue;
        if (collide_circle(cx, cy, SHIP_R, aliens[i].cx, aliens[i].cy, ALIEN_H[aliens[i].type] / 4))
            return true;
    }
    return false;
}

/* --- Enemy --- */

ALIEN aliens[ALIENS_N];
// �ۼ��� : �ڳ���
/* Ÿ�Ժ� ü�� �� �ӵ� ���� */

void aliens_init()
{
    for (int i = 0; i < ALIENS_N; i++)
        aliens[i].used = false;
}

//0329 �ڳ��� - stage ���� ��� ������Ʈ
void aliens_update()
{
    int spawn_frames = (int)(60 * CURR_STAGE->spawn_interval);
    int new_quota = (frames % spawn_frames) ? 0 : between(4, 6);

    int curr_alive_alien = 0;

    // �ۼ��� : õ���� & �ڳ���
    /* --- �� ���� �� �ʱ�ȭ --- */
    for (int i = 0; i < ALIENS_N; i++)
    {
        if (!aliens[i].used)
        {
            // if this alien is unused, should it spawn?
            if (new_quota > 0 && curr_alive_alien < CURR_STAGE->max_enemies)
            {
                float life_mul = CURR_STAGE->life_multiplier;
                float new_x, new_y;

                spawn_enemy(&new_x, &new_y, i);

                aliens[i].type = decide_enemy_type();
                set_aliens_info(i, life_mul);
                aliens[i].x = new_x;
                aliens[i].y = new_y;

                aliens[i].cx = aliens[i].x + (ALIEN_W[aliens[i].type] / 2.0f);
                aliens[i].cy = aliens[i].y + (ALIEN_H[aliens[i].type] / 2.0f);

                aliens[i].shot_timer = between(1, 99);
                aliens[i].blink = 0;
                aliens[i].used = true;

                new_quota--;
            }
            continue;
        }


        // �ۼ��� : õ����
        // ��-> ĳ���� �������� ������
        switch (aliens[i].type)
        {
        case ALIEN_TYPE_METEOR:
            aliens_move(i, aliens[i].speed);
            break;

        case ALIEN_TYPE_FAST:
            aliens_move(i, aliens[i].speed);
            break;

        case ALIEN_TYPE_SHOOTER:
            aliens_move(i, aliens[i].speed);
            break;

        case ALIEN_TYPE_BOSS:
            aliens_move(i, aliens[i].speed);
        }

        ///* ȭ�� ���� ������ ������, ����*/
        //if (aliens[i].x > BUFFER_W + 100 ||
        //    aliens[i].x < -100 ||
        //    aliens[i].y > BUFFER_H + 100 ||
        //    aliens[i].y < -100)
        //{
        //    aliens[i].used = false;
        //    continue;
        //}
        
        //0330

        /* �� ���� ������ ���� ��, �ݴ������� ���� (���� �� ����) */
        if (aliens[i].x > MAP_WIDTH)  aliens[i].x = 0;
        if (aliens[i].x < 0)          aliens[i].x = MAP_WIDTH;
        if (aliens[i].y > MAP_HEIGHT) aliens[i].y = 0;
        if (aliens[i].y < 0)          aliens[i].y = MAP_HEIGHT;


        ///* ���ּ��� �ʹ� �־����� ���� (��: 2000 �ȼ� �̻�) */
        //float dx = aliens[i].x - ship.x;
        //float dy = aliens[i].y - ship.y;
        //float distance_sq = dx * dx + dy * dy; // ��Ʈ ��꺸�� ���� �񱳰� �����ϴ�.

        //if (distance_sq > 2000 * 2000)
        //{
        //    aliens[i].used = false;
        //    continue;
        //}

        if (aliens[i].blink)
            aliens[i].blink--;

        if (shots_collide(false, aliens[i].x, aliens[i].y, ALIEN_W[aliens[i].type], ALIEN_H[aliens[i].type]))
        {
            aliens[i].life -= ship.damage;
            aliens[i].blink = 4;
        }

        if (aliens[i].life <= 0)
        {
            float score_mul = CURR_STAGE->score_multiplier;
            fx_add(false, aliens[i].cx, aliens[i].cy);

			switch (aliens[i].type)
			{
			case ALIEN_TYPE_METEOR:
				score += (int)(ALIEN_SCORE_METEOR * score_mul);
				break;

			case ALIEN_TYPE_FAST:
				score += (int)(ALIEN_SCORE_FAST * score_mul);
				break;

			case ALIEN_TYPE_SHOOTER:
				score += (int)(ALIEN_SCORE_SHOOTER * score_mul);
                fx_add(false, aliens[i].cx - 10, aliens[i].cy - 4);
                fx_add(false, aliens[i].cx + 4, aliens[i].cy + 10);
                fx_add(false, aliens[i].cx + 8, aliens[i].cy + 8);
                break;
            case ALIEN_TYPE_BOSS:
                score += (int)(ALIEN_SCORE_BOSS * score_mul);
                fx_add(false, aliens[i].cx - 10, aliens[i].cy - 4);
                fx_add(false, aliens[i].cx + 4, aliens[i].cy + 10);
                fx_add(false, aliens[i].cx + 8, aliens[i].cy + 8);
                break;
            }

            aliens[i].used = false;
            //0327 �ڳ��� - ������ ���
            item_add(aliens[i].cx, aliens[i].cy, aliens[i].type);
            continue;
        }

        aliens[i].shot_timer--;
        if (aliens[i].shot_timer == 0)
        {
            switch (aliens[i].type)
            {
            case ALIEN_TYPE_METEOR:    //���׿��� ���� ���� �ʴ´�.
                /*shots_add(false, false, cx, cy);
                aliens[i].shot_timer = 150;*/
                break;
            case ALIEN_TYPE_FAST:
                shots_add(false, true, aliens[i].cx, aliens[i].cy, aliens[i].shot_count);
                aliens[i].shot_timer = 80;
                break;
            case ALIEN_TYPE_SHOOTER:
                shots_add(false, true, aliens[i].cx - 5, aliens[i].cy, aliens[i].shot_count);
                shots_add(false, true, aliens[i].cx + 5, aliens[i].cy, aliens[i].shot_count);
                shots_add(false, true, aliens[i].cx - 5, aliens[i].cy + 8, aliens[i].shot_count);
                shots_add(false, true, aliens[i].cx + 5, aliens[i].cy + 8, aliens[i].shot_count);
                aliens[i].shot_timer = 200;
                break;
            case ALIEN_TYPE_BOSS:
                shots_add(false, true, aliens[i].cx - 200, aliens[i].cy - 100, aliens[i].shot_count);
                aliens[i].shot_timer = 50;
                aliens[i].shot_count = 5;
                break;
            }
        }
    }
    aliens_collide();
}

//0329 �ڳ���
void spawn_enemy(float* new_x, float* new_y, int i)
{
    int spawn_dup_check = 0;
    while (!spawn_dup_check)
    {
        int side = between(0, 4);
        switch (side)
        {
            //0330x
		case 0: //��
			/**new_x = between(10, BUFFER_W - 10);
			*new_y = between(-40, -30);*/
			*new_x = between(ship.cx - 640, ship.cx + 640);
			*new_y = between(ship.cy - 360 - 30, ship.cy - 360);
			break;
		case 1: //��
			//*new_x = between(10, BUFFER_W - 10);
			//*new_y = between(BUFFER_H + 30, BUFFER_H + 60);
			*new_x = between(ship.cx - 640, ship.cx + 640);
			*new_y = between(ship.cy + 360, ship.cy + 360 + 30);
			break;
		case 2: //��
			*new_x = between(ship.cx - 640 - 40, ship.cx - 640);
			*new_y = between(ship.cy - 360, ship.cy + 360);
			break;
        case 3: //��
            *new_x = between(ship.cx + 640, ship.cx + 640 + 40);
            *new_y = between(ship.cy - 360, ship.cy + 360);
            break;
        }
        spawn_dup_check = 1;
        for (int j = 0; j < ALIENS_N; j++)
        {
            if (aliens[j].used && i != j)
            {
                float dx = aliens[j].x - *new_x;
                float dy = aliens[j].y - *new_y;
                if (dx * dx + dy * dy < 1000) {
                    spawn_dup_check = 0;
                    break;
                }
            }
        }
    }
}

//0329 �ڳ���
void spawn_boss()
{
    for (int i = 0; i < ALIENS_N; ++i)
    {
        if (!aliens[i].used)
        {
            float life_mul = CURR_STAGE->life_multiplier;
            float new_x, new_y;
            spawn_enemy(&new_x, &new_y, i);
            
            aliens[i].type = ALIEN_TYPE_BOSS;

            set_aliens_info(i, life_mul);
            aliens[i].x = new_x;
            aliens[i].y = new_y;
            aliens[i].cx = aliens[i].x + (ALIEN_W[aliens[i].type] / 2.0f);
            aliens[i].cy = aliens[i].y + (ALIEN_H[aliens[i].type] / 2.0f);

            aliens[i].shot_timer = 5;
            aliens[i].blink = 0;
            aliens[i].used = true;
            break;
        }
    }
}
//0329 �ڳ���
bool is_boss_alive()
{
    for (int i = 0; i < ALIENS_N; ++i)
    {
        if (aliens[i].used && aliens[i].type == ALIEN_TYPE_BOSS)
            return true;
    }
    return false;
}
//0329 �ڳ���
 int decide_enemy_type()
{
    int rand_num = between(0, 100);
    int cumulate = 0;
    int type = 0;
    for (int i = 0; i < ALIEN_TYPE_N; ++i)
    {
        cumulate += CURR_STAGE->spawn_weight[i];
        if (rand_num < cumulate)
        {
            type = i;
            break;
        }
    }
    return type;
}

 void set_aliens_info(int i, float life_mul)
 {
     switch (aliens[i].type)
     {
     case ALIEN_TYPE_METEOR:
         aliens[i].life = ALIEN_LIFE_METEOR * life_mul;
         aliens[i].speed = 2.0f;
         aliens[i].shot_count = ALIEN_SHOT_METEOR;
         break;
     case ALIEN_TYPE_FAST:
         aliens[i].life = ALIEN_LIFE_FAST * life_mul;
         aliens[i].speed = 2.5f;
         aliens[i].shot_count = ALIEN_SHOT_FAST;
         break;
     case ALIEN_TYPE_SHOOTER:
         aliens[i].life = ALIEN_LIFE_SHOOTER * life_mul;
         aliens[i].speed = 2.0f;
         aliens[i].shot_count = ALIEN_SHOT_SHOOTER;
         break;
     case ALIEN_TYPE_BOSS:
         aliens[i].life = ALIEN_LIFE_BOSS * life_mul;
         aliens[i].shot_count = ALIEN_SHOT_BOSS;
         break;
     }
 }
// �ۼ��� : �ڳ���
void aliens_move(int i, float speed)
{
    float dx = ship.cx - aliens[i].cx;
    float dy = ship.cy - aliens[i].cy;

	if (dx > (MAP_WIDTH / 2)) dx -= MAP_WIDTH;
	else if (dx < -(MAP_WIDTH / 2)) dx += MAP_WIDTH;

	if (dy > (MAP_HEIGHT / 2)) dy -= MAP_HEIGHT;
	else if (dy < -(MAP_HEIGHT / 2)) dy += MAP_HEIGHT;

    if (dx < 0) aliens[i].x -= speed;
    if (dx > 0) aliens[i].x += speed;
    if (dy < 0) aliens[i].y -= speed;
    if (dy > 0) aliens[i].y += speed;

	if (aliens[i].x < 0) aliens[i].x += MAP_WIDTH;
	if (aliens[i].x > MAP_WIDTH) aliens[i].x -= MAP_WIDTH;
	if (aliens[i].y < 0) aliens[i].y += MAP_HEIGHT;
	if (aliens[i].y > MAP_HEIGHT) aliens[i].y -= MAP_HEIGHT;

    aliens[i].cx = aliens[i].x + (ALIEN_W[aliens[i].type] / 2.0f);
    aliens[i].cy = aliens[i].y + (ALIEN_H[aliens[i].type] / 2.0f);

}

//0330
void aliens_draw()
{
    for (int i = 0; i < ALIENS_N; i++)
    {
        if (!aliens[i].used)
            continue;
        if (aliens[i].blink > 2)
            continue;

        float between_angle = atan2(ship.y - aliens[i].y, ship.x - aliens[i].x) + (ALLEGRO_PI / 2.0);

        aliens_single_draw(between_angle, i, aliens[i].cx, aliens[i].cy);

        if(aliens[i].cx > MAP_WIDTH - 640)
            aliens_single_draw(between_angle, i, aliens[i].cx - MAP_WIDTH, aliens[i].cy);
        if(aliens[i].cx < 640)
            aliens_single_draw(between_angle, i, aliens[i].cx + MAP_WIDTH, aliens[i].cy);
        if (aliens[i].cy > MAP_HEIGHT - 640)
            aliens_single_draw(between_angle, i, aliens[i].cx, aliens[i].cy - MAP_HEIGHT);
        if (aliens[i].cy < 640)
            aliens_single_draw(between_angle, i, aliens[i].cx, aliens[i].cy + MAP_HEIGHT);
    }
}
//0330
void aliens_single_draw(float between_angle, int i, float cx, float cy)
{
    al_draw_scaled_rotated_bitmap(sprites.alien[aliens[i].type],
        (float)ALIEN_W[aliens[i].type] / 2.0f, (float)ALIEN_H[aliens[i].type] / 2.0f,
        cx, cy,
        0.5, 0.5,
        between_angle,
        0);
}
void aliens_collide()
{
    for (int i = 0; i < ALIENS_N; i++)
    {
        if (!aliens[i].used) continue;

        for (int j = i + 1; j < ALIENS_N; j++)
        {
            if (!aliens[j].used) continue;

            float r_i = ALIEN_W[aliens[i].type] / 4.0f;
            float r_j = ALIEN_W[aliens[j].type] / 4.0f;

            if (collide_circle(aliens[i].cx, aliens[i].cy, r_i, aliens[j].cx, aliens[j].cy, r_j))
            {
                float dx = aliens[i].cx - aliens[j].cx;
                float dy = aliens[i].cy - aliens[j].cy;
                float dist = sqrtf(dx * dx + dy * dy);

                // �� ���� ������ ���ļ� �Ÿ��� 0�� ��� ���� ó�� (������ 0 ����)
                if (dist == 0) {
                    aliens[i].x += 1; // ������ ��¦ ����߸�
                    continue;
                }
                float overlap = (r_i + r_j) - dist;

                float nx = dx / dist;
                float ny = dy / dist;

                float move_x = nx * overlap * 0.5f;
                float move_y = ny * overlap * 0.5f;

                aliens[i].x += move_x;
                aliens[i].y += move_y;
                aliens[j].x -= move_x;
                aliens[j].y -= move_y;

                aliens[i].cx = aliens[i].x + (ALIEN_W[aliens[i].type] / 2.0f);
                aliens[i].cy = aliens[i].y + (ALIEN_H[aliens[i].type] / 2.0f);
                aliens[j].cx = aliens[j].x + (ALIEN_W[aliens[j].type] / 2.0f);
                aliens[j].cy = aliens[j].y + (ALIEN_H[aliens[j].type] / 2.0f);
            }
        }
    }
}